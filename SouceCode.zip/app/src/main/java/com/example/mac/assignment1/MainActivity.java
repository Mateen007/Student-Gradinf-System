package com.example.mac.assignment1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView stid = null;
    TextView courseid = null;
    TextView mark = null;
    Button see = null;
    TextView viewname = null;
    TextView viewcoid = null;
    TextView viewmark = null;
    TextView viewgpa = null;
    String StudentId,ClassId,Marks,gpa;
    double e;

    @Override



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        stid = findViewById(R.id.tvname);
        courseid= findViewById(R.id.tvid2);
        mark = findViewById(R.id.tvmark3);


        viewname = findViewById(R.id.textViewname);
        viewcoid = findViewById(R.id.Corsid);
        viewmark = findViewById(R.id.Mark1);
        viewgpa = findViewById(R.id.total);

    }




    public void button(View view) {

        StudentId = stid.getText().toString();
        int ID = Integer.parseInt(StudentId);
        viewname.setText("Student ID:         \t\t"+ ID);

        ClassId = courseid.getText().toString();
        viewcoid.setText("Course ID:         \t\t"+ ClassId);

        Marks = mark.getText().toString();
        e = Double.parseDouble(Marks);
        viewmark.setText("Total Marks: \t\t\t" + e);


        grading();
        viewgpa.setText("Grade: \t\t\t\t\t\t\t\t"+gpa);

    }
    public void grading(){



        if (e >= 94 && e<=100){
            gpa ="A";
            Toast.makeText(this,"Amazing, You should be Proud", Toast.LENGTH_SHORT).show();
        }
        else if (e < 94 && e >=90) {
            gpa = "-A";
            Toast.makeText(this,"Great Job", Toast.LENGTH_SHORT).show();
        }
        else if (e < 90 && e >=87){
            gpa = "B+";
            Toast.makeText(this,"Excellent", Toast.LENGTH_SHORT).show();
        }
        else if (e < 87 && e >=84){
            gpa = "B";
            Toast.makeText(this,"Well Done", Toast.LENGTH_SHORT).show();
        }
        else if (e < 84 && e >=80){
            gpa = "B-";
            Toast.makeText(this,"Fine, Try Harder", Toast.LENGTH_SHORT).show();
        }
        else if (e < 80 && e >=77){
            gpa = "C+";
            Toast.makeText(this,"You could have done better", Toast.LENGTH_SHORT).show();
        }
        else if (e < 77 && e >=74){
            gpa = "C";
            Toast.makeText(this,"dont be a retard and work hard", Toast.LENGTH_SHORT).show();
        }
        else if (e < 74 && e >=70){
            gpa = "C-";
            Toast.makeText(this,"Come on, STUDY", Toast.LENGTH_SHORT).show();
        }
        else if (e < 70 && e >=67){
            gpa = "D+";
            Toast.makeText(this,"SERIOUSLY?", Toast.LENGTH_SHORT).show();
        }
        else if (e < 67 && e >=64){
            gpa = "D";
            Toast.makeText(this,"Its Such a Shame", Toast.LENGTH_SHORT).show();
        }
        else if (e < 64 && e >=60){
            gpa = "D-";
            Toast.makeText(this,"I am sorry for you.", Toast.LENGTH_SHORT).show();
        }
        else if (e<60){
            gpa = "F";
            Toast.makeText(this,"You loser.", Toast.LENGTH_SHORT).show();
        }
        else if (e>100){
            gpa = "Write Valid Marks";
            Toast.makeText(this,"Try to Write valid Marks", Toast.LENGTH_SHORT).show();
        }




    }
}
